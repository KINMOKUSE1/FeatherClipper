/* Shared by the course page, background worker, and tests. */
(function (root) {
  const marker = "<!-- boc-course-index:v1 -->";
  function safeName(value) {
    const name = String(value || "").normalize("NFC").replace(/[<>:"/\\|?*\x00-\x1f\[\]#^]/g, "_").replace(/[. ]+$/g, "").trim();
    return (name || "未命名").slice(0, 70);
  }
  function normalizeFolder(value) {
    const parts = String(value || "").trim().replace(/\\/g, "/").split("/");
    if (!parts.length || parts.some(p => !p || p === "." || p === ".." || /[<>:"|?*\x00-\x1f]/.test(p) || /[. ]$/.test(p))) {
      throw new Error("请输入笔记库内的相对目录，例如 Clippings/Bilibili。");
    }
    return parts.join("/");
  }
  function chapterOf(title) {
    const match = String(title).match(/^\s*(\d{1,3})[.．]/);
    return match ? String(Number(match[1])) : "0";
  }
  function chapterLabel(chapter) {
    return Number(chapter) > 0 ? `第${String(Number(chapter)).padStart(2, "0")}章` : "未分章";
  }
  function parseSource(source) {
    const value = String(source || "").trim();
    if (/^BV[0-9A-Za-z]+$/.test(value)) return { platform: "bilibili", id: value, page: 1 };
    let url;
    try { url = new URL(value); } catch { return null; }
    if (url.protocol !== "https:") return null;
    if (url.hostname === "www.bilibili.com") {
      const id = url.pathname.match(/^\/video\/(BV[0-9A-Za-z]+)/)?.[1];
      return id ? { platform: "bilibili", id, page: Math.max(1, Number(url.searchParams.get("p")) || 1) } : null;
    }
    const id = url.hostname === "youtu.be" ? url.pathname.replace(/^\/+|\/+$/g, "") :
      ["www.youtube.com", "youtube.com", "m.youtube.com"].includes(url.hostname) && url.pathname === "/watch" ? url.searchParams.get("v") : null;
    if (!/^[\w-]{11}$/.test(id || "")) return null;
    const playlistId = /^[\w-]{8,60}$/.test(url.searchParams.get("list") || "") ? url.searchParams.get("list") : "";
    return { platform: "youtube", id, playlistId, page: 1 };
  }
  function courseFolder(meta, base) {
    return `${normalizeFolder(base)}/${safeName(meta.title)} [${meta.platform === "youtube" ? meta.playlistId ? `YT-PL-${meta.playlistId}` : `YT-${meta.videoId}` : meta.bvid}]`;
  }
  function rawPath(meta, page, base) {
    return `${courseFolder(meta, base)}/原始字幕/${safeName(page.part)} [${meta.platform === "youtube" ? `YT-${page.cid}` : `CID-${page.cid}`}].md`;
  }
  function videoUrl(meta, page) {
    return meta.platform === "youtube" ? `https://www.youtube.com/watch?v=${page.cid}` : `https://www.bilibili.com/video/${meta.bvid}/?p=${page.page}`;
  }
  function timestampUrl(meta, page, seconds) {
    const url = new URL(videoUrl(meta, page));
    url.searchParams.set("t", String(Math.floor(seconds)));
    return url.href;
  }
  function timestamp(seconds) {
    const n = Math.max(0, Math.floor(Number(seconds) || 0));
    return [Math.floor(n / 3600), Math.floor(n % 3600 / 60), n % 60].map(x => String(x).padStart(2, "0")).join(":");
  }
  function buildRaw(meta, page, track, body) {
    const q = JSON.stringify;
    const partTitle = String(page.part || "").replace(/\r?\n/g, " ").trim() || `P${page.page}`;
    return ["---", `title: ${q(partTitle)}`, `course: ${q(meta.title)}`,
      `url: ${q(videoUrl(meta, page))}`, ...(meta.platform === "youtube" ? [`platform: youtube`, `youtube_id: ${q(page.cid)}`] : [`bvid: ${q(meta.bvid)}`, `cid: ${q(page.cid)}`]),
      `page: ${page.page}`, `chapter: ${q(page.chapter)}`, `author: ${q(meta.author)}`,
      `subtitle_lang: ${q(track.lanDoc || track.lan)}`, ...(track.source ? [`subtitle_source: ${q(track.source)}`] : []), `created: ${q(new Date().toISOString())}`,
      `tags: [clippings, ${meta.platform === "youtube" ? "youtube" : "bilibili"}, course-source]`, "---", "", `# ${partTitle}`, "",
      track.source === "local-asr" ? "> 本地模型转写的原始素材，可能有错词。请结合视频核对；板书、图表和公式仍需回看。" : "> 原始字幕素材。章节归属以课程导入清单为准；字幕不能完整替代视频中的板书、图表和公式。", "", "## 字幕", "",
      ...body.map(item => `[${timestamp(item.from)}](${timestampUrl(meta, page, item.from)}) ${String(item.content).replace(/\r?\n/g, " ")}`), ""].join("\n");
  }
  function tableText(value) { return String(value || "").replace(/\|/g, "\\|").replace(/[\r\n]/g, " "); }
  function buildStudyPrompt(meta, pages, base) {
    const folder = normalizeFolder(base);
    const targets = pages.filter(page => page.selected);
    if (meta && !targets.length) throw new Error("请先在课程列表勾选要整理的分 P。");
    const lines = ["请按我提供的学习规则和笔记模板整理本次课程素材；已安装 course-notes 技能时可使用该技能，个人文档优先于技能默认值。",
      `学习规则：${folder}/学习工作流/WORKFLOW.md`,
      `笔记模板：${folder}/学习工作流/NOTE_TEMPLATE.md`];
    if (meta && targets.length) {
      lines.push(`课程：${meta.title}`, `课程清单：${courseFolder(meta, folder)}/课程导入清单.md`,
        `本次范围：${targets.map(page => `P${page.page}`).join("、")}。`,
        ...targets.map(page => `- P${page.page} ${page.part}：${page.sourcePath || rawPath(meta, page, folder)}`),
        "核对这些文件的实际可用情况。本次只处理上述 P；按课程清单和学习规则确定笔记范围与组织方式。");
    } else {
      lines.push("课程目录：[填写已导入课程的目录]", "本次范围：[填写章号、P序号或文件名]");
    }
    lines.push("请读取上述学习文档、课程清单与所选素材，按其中的个人偏好整理。",
      "使用可访问笔记库的 Agent 时直接读取上述文件；使用网页聊天工具时，我会一并上传或粘贴文档与素材。");
    return lines.join("\n");
  }
  function buildIndex(meta, pages, base) {
    const lines = [marker, `# ${meta.title} · 课程导入清单`, "", "> 此文件由批量导入器更新。学习批注请写入最终章节笔记。", "",
      `课程：[${meta.platform === "youtube" ? meta.playlistId || meta.videoId : meta.bvid}](${meta.playlistId ? `https://www.youtube.com/playlist?list=${meta.playlistId}` : videoUrl(meta, pages[0])})`, `更新：${new Date().toISOString()}`, "",
      meta.platform === "youtube" ? "原始字幕以视频标题命名，YouTube 视频 ID 用于避免同名冲突。" : "原始字幕以分 P 名称命名，CID 用于区分同名视频；分章以本清单为准。", "",
      "下一步：在导入器点击“开始整理笔记”，保存学习指南与模板，或下载 course-notes 技能。将本清单与指定范围的字幕交给你选择的 AI，按章整理学习笔记。", ""];
    const chapters = [...new Set(pages.map(p => p.chapter))].sort((a, b) => Number(a) - Number(b));
    for (const chapter of chapters) {
      lines.push(`## ${chapterLabel(chapter)}`, "", "| P | 标题 | 状态 | 原始素材 |", "|---|---|---|---|");
      for (const page of pages.filter(p => p.chapter === chapter)) {
        const available = ["saved", "exists"].includes(page.status);
        const labels = { saved: "已导入", exists: "已存在，跳过", missing: "无可用字幕", failed: "失败", pending: "待导入", running: "待核实" };
        const status = `${labels[page.status] || "待导入"}${page.error ? `：${page.error}` : ""}`;
        const filename = (page.sourcePath || rawPath(meta, page, base)).split("/").pop();
        const link = available ? `[字幕](<原始字幕/${filename}>)` : "—";
        lines.push(`| [P${page.page}](${videoUrl(meta, page)}) | ${tableText(page.part)} | ${tableText(status)} | ${link} |`);
      }
      lines.push("");
    }
    return lines.join("\n");
  }
  root.CourseCore = { marker, safeName, normalizeFolder, chapterOf, chapterLabel, parseSource, courseFolder, rawPath, videoUrl, timestampUrl, buildRaw, buildIndex, buildStudyPrompt };
  if (typeof module !== "undefined") module.exports = root.CourseCore;
})(globalThis);
