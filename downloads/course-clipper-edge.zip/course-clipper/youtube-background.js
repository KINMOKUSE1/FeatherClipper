/* Read YouTube's available caption tracks in the video page's own browser session. */
async function youtubePageRead(videoId, preference, includeBody, includeAudio, playlistId) {
  const currentId = new URL(location.href).searchParams.get("v");
  if (currentId !== videoId) throw new Error("YouTube 页面已切换视频，请重新读取。");
  const inlineJson = name => {
    const marker = new RegExp(`\\b${name}\\s*=\\s*\\{`);
    for (const script of document.scripts) {
      const text = script.textContent || "";
      const match = marker.exec(text);
      if (!match) continue;
      const start = match.index + match[0].lastIndexOf("{");
      let depth = 0, quoted = false, escaped = false;
      for (let index = start; index < text.length; index++) {
        const char = text[index];
        if (quoted) {
          if (escaped) escaped = false;
          else if (char === "\\") escaped = true;
          else if (char === '"') quoted = false;
        } else if (char === '"') quoted = true;
        else if (char === "{") depth++;
        else if (char === "}" && --depth === 0) {
          try { return JSON.parse(text.slice(start, index + 1)); }
          catch { break; }
        }
      }
    }
    return null;
  };
  let player = window.ytInitialPlayerResponse;
  if (player?.videoDetails?.videoId !== videoId) {
    try { player = JSON.parse(window.ytplayer?.config?.args?.player_response || "null"); }
    catch { player = null; }
  }
  if (player?.videoDetails?.videoId !== videoId) player = inlineJson("ytInitialPlayerResponse");
  const inlinePlayer = player?.videoDetails?.videoId === videoId ? player : null;
  if (player?.videoDetails?.videoId !== videoId || !player?.captions?.playerCaptionsTracklistRenderer?.captionTracks?.length) {
    try {
      const response = await fetch("/youtubei/v1/player?prettyPrint=false", {
        method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ context: { client: { clientName: "IOS", clientVersion: "20.10.3" } }, videoId }),
        signal: AbortSignal.timeout(4000)
      });
      if (response.ok) {
        const fresh = await response.json();
        if (fresh?.videoDetails?.videoId === videoId) player = fresh;
      }
    } catch { /* The inline player response may still be usable. */ }
  }
  if (player?.playabilityStatus?.status === "LOGIN_REQUIRED") throw new Error("YouTube 要求验证登录状态；请在 Edge 打开视频并确认能播放后重试。");
  const details = player?.videoDetails;
  if (!details || details.videoId !== videoId) throw new Error("无法读取 YouTube 视频信息；请先打开视频页并确认能播放。");
  const meta = { platform: "youtube", videoId, bvid: `YT_${videoId}`, title: details.title || document.title.replace(/\s*-\s*YouTube$/, ""), author: details.author || "", pages: [{ cid: videoId, page: 1, part: details.title || "视频字幕", duration: Number(details.lengthSeconds) || 0 }] };
  if (playlistId && !includeBody && !includeAudio) {
    if (new URL(location.href).searchParams.get("list") !== playlistId) throw new Error("YouTube 页面已切换播放列表，请重新读取。");
    const playlist = (window.ytInitialData || inlineJson("ytInitialData"))?.contents?.twoColumnWatchNextResults?.playlist?.playlist;
    const entries = (playlist?.contents || []).map(item => item.playlistPanelVideoRenderer).filter(Boolean);
    const fromData = entries.map(item => ({ cid: item.videoId, part: item.title?.simpleText || item.title?.runs?.map(run => run.text).join("") || "视频字幕", duration: Number(item.lengthSeconds) || 0 }));
    const fromDom = [...document.querySelectorAll("ytd-playlist-panel-video-renderer")].map(item => {
      const link = item.querySelector("a#wc-endpoint");
      let cid = "";
      try { cid = new URL(link?.href || "", location.href).searchParams.get("v") || ""; } catch { /* Ignore unavailable item. */ }
      return { cid, part: item.querySelector("#video-title")?.textContent?.trim() || link?.title || "视频字幕", duration: 0 };
    });
    const items = fromData.length >= fromDom.length ? fromData : fromDom;
    const unique = [...new Map(items.filter(item => /^[\w-]{11}$/.test(item.cid)).map(item => [item.cid, item])).values()];
    if (!unique.length) throw new Error("无法读取 YouTube 播放列表目录；请在浏览器中打开列表中的视频后重试。");
    meta.playlistId = playlistId;
    meta.bvid = `YTPL_${playlistId}`;
    meta.title = (typeof playlist?.title === "string" ? playlist.title : "") || document.querySelector("ytd-playlist-panel-renderer #title")?.textContent?.trim() || details.title;
    meta.pages = unique.map((item, index) => ({ ...item, page: index + 1 }));
  }
  if (includeAudio) {
    const formats = (player.streamingData?.adaptiveFormats || inlinePlayer?.streamingData?.adaptiveFormats || []).filter(item => String(item.mimeType || "").startsWith("audio/") && item.url);
    const audioUrls = formats.sort((a, b) => Number(a.bitrate || 0) - Number(b.bitrate || 0)).map(item => item.url).filter(value => {
      try { const url = new URL(value); return url.protocol === "https:" && (url.hostname === "googlevideo.com" || url.hostname.endsWith(".googlevideo.com")); }
      catch { return false; }
    }).slice(0, 4);
    if (!audioUrls.length) throw new Error("YouTube 没有提供可用的音轨地址，暂时无法启动本地转写。");
    return { meta, audioUrls };
  }
  if (!includeBody) return { meta };
  const renderer = player?.captions?.playerCaptionsTracklistRenderer;
  const tracks = Array.isArray(renderer?.captionTracks) ? renderer.captionTracks : [];
  const language = String(preference || "auto").toLowerCase();
  const name = track => track.name?.simpleText || track.name?.runs?.map(run => run.text || "").join("") || track.languageCode || "字幕";
  const family = track => String(track.languageCode || "").toLowerCase().split("-")[0];
  let candidates = language === "auto" ? tracks : tracks.filter(track => family(track) === language);
  if (language === "auto") {
    const audio = renderer?.audioTracks?.[renderer.defaultAudioTrackIndex || 0] || renderer?.audioTracks?.[0];
    const defaultTrack = tracks[audio?.defaultCaptionTrackIndex ?? renderer?.defaultCaptionTrackIndex];
    const spoken = tracks.find(track => track.kind === "asr");
    const original = defaultTrack || (spoken && tracks.find(track => track.kind !== "asr" && family(track) === family(spoken))) || spoken;
    candidates = [...tracks].sort((a, b) => {
      const rank = track => family(track) === "zh" ? 0 : track === original ? 1 : track.kind !== "asr" ? 2 : 3;
      return rank(a) - rank(b);
    });
  } else candidates = [...candidates].sort((a, b) => Number(a.kind === "asr") - Number(b.kind === "asr"));
  async function readRenderedTranscript(openPanel) {
    const transcriptSelector = 'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"] #segments-container';
    let container = document.querySelector(transcriptSelector);
    if (openPanel && !container?.querySelector("ytd-transcript-segment-renderer")) {
      const button = document.querySelector("ytd-video-description-transcript-section-renderer button");
      button?.click();
      if (button) {
        for (let attempt = 0; attempt < 20; attempt++) {
          container = document.querySelector(transcriptSelector);
          if (container?.querySelector("ytd-transcript-segment-renderer")) break;
          await new Promise(resolve => setTimeout(resolve, 250));
        }
      }
    }
    if (container?.querySelector("ytd-transcript-segment-renderer")) {
      const selectedName = document.querySelector(
        'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"] #footer yt-sort-filter-sub-menu-renderer yt-dropdown-menu button'
      )?.textContent?.trim() || "";
      const normalized = value => value.replace(/\s*\([^)]*\)\s*/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
      const selectedTrack = tracks.find(track => normalized(name(track)) === normalized(selectedName))
        || (tracks.length === 1 ? tracks[0] : null);
      const selectedFamily = selectedTrack ? family(selectedTrack)
        : /English|英语|英文/i.test(selectedName) ? "en"
        : /中文|汉语|Chinese/i.test(selectedName) ? "zh" : "";
      if (language === "auto" || selectedFamily === language) {
        const seconds = value => {
          const parts = value.split(":").map(Number);
          return parts.length >= 2 && parts.length <= 3 && parts.every(Number.isFinite)
            ? parts.reduce((total, part) => total * 60 + part, 0) : NaN;
        };
        const body = [...container.querySelectorAll("ytd-transcript-segment-renderer")].map(item => ({
          from: seconds(item.querySelector(".segment-timestamp")?.textContent?.trim() || ""),
          content: item.querySelector(".segment-text")?.textContent?.replace(/\s+/g, " ").trim() || ""
        })).filter(item => Number.isFinite(item.from) && item.content);
        if (body.length) {
          const track = selectedTrack || candidates.find(item => family(item) === selectedFamily);
          return { meta, track: { lan: track?.languageCode || selectedFamily, lanDoc: selectedName || (track ? name(track) : "字幕"), source: "youtube-transcript-panel" }, body };
        }
      }
    }
    return null;
  }
  const visible = await readRenderedTranscript(false);
  if (visible) return visible;
  const deadline = Date.now() + 12000;
  const captionFetch = (url, options = {}) => {
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw new Error("YouTube 字幕读取超时");
    return fetch(url, { ...options, signal: AbortSignal.timeout(Math.min(4000, remaining)) });
  };
  let emptyTrack = false;
  for (const track of candidates.slice(0, 3)) {
    let url;
    try { url = new URL(track.baseUrl); } catch { continue; }
    if (url.protocol !== "https:" || !(url.hostname === "youtube.com" || url.hostname.endsWith(".youtube.com"))) continue;
    // YouTube's protected timedtext URLs advertise a track but return HTTP 200 with an empty body.
    if (url.searchParams.get("exp") === "xpe") { emptyTrack = true; continue; }
    for (const format of ["json3", "original"]) {
      const target = new URL(url);
      if (format === "json3") target.searchParams.set("fmt", "json3");
      let response;
      try { response = await captionFetch(target.href, { credentials: "include" }); }
      catch { continue; }
      if (!response.ok) continue;
      const text = await response.text();
      if (!text.trim()) { emptyTrack = true; continue; }
      let body = [];
      if (format === "json3") {
        try {
          const data = JSON.parse(text);
          body = (data.events || []).filter(event => Array.isArray(event.segs)).map(event => ({
            from: Number(event.tStartMs) / 1000,
            to: (Number(event.tStartMs) + Number(event.dDurationMs || 0)) / 1000,
            content: event.segs.map(seg => seg.utf8 || "").join("").replace(/\s+/g, " ").trim()
          })).filter(item => Number.isFinite(item.from) && item.content);
        } catch { /* Try the track's original format. */ }
      } else {
        const xml = new DOMParser().parseFromString(text, "text/xml");
        body = [...xml.querySelectorAll("text, p")].map(item => {
          const from = item.tagName === "p" ? Number(item.getAttribute("t")) / 1000 : Number(item.getAttribute("start"));
          const duration = item.tagName === "p" ? Number(item.getAttribute("d")) / 1000 : Number(item.getAttribute("dur"));
          return { from, to: from + (Number.isFinite(duration) ? duration : 0), content: (item.textContent || "").replace(/\s+/g, " ").trim() };
        }).filter(item => Number.isFinite(item.from) && item.content);
      }
      if (body.length) return { meta, track: { lan: track.languageCode || "", lanDoc: name(track), source: track.kind === "asr" ? "youtube-auto-caption" : "youtube-caption" }, body };
      emptyTrack = true;
    }
  }
  // WEB caption URLs can advertise tracks while returning an empty body (exp=xpe).
  // Ask the iOS player for a fresh URL before trying other clients.
  const apiKey = window.ytcfg?.get?.("INNERTUBE_API_KEY");
  for (const client of [
    { clientName: "IOS", clientVersion: "20.10.3" },
    { clientName: "ANDROID", clientVersion: "20.10.38", androidSdkVersion: 30 },
    { clientName: "MWEB", clientVersion: "2.20250312.04.00" }
  ]) {
    try {
      const response = await captionFetch("/youtubei/v1/player?prettyPrint=false", {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", ...(language === "auto" ? {} : { "Accept-Language": language }) },
        body: JSON.stringify({ context: { client: { ...client, hl: "en" } }, videoId })
      });
      if (!response.ok) continue;
      const mobile = await response.json();
      if (mobile.videoDetails?.videoId && mobile.videoDetails.videoId !== videoId) continue;
      const mobileTracks = mobile.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
      const selected = language === "auto"
        ? [...mobileTracks].sort((a, b) => Number(family(a) !== "zh") - Number(family(b) !== "zh"))
        : mobileTracks.filter(track => family(track) === language);
      if (selected.length) candidates = selected;
      for (const track of selected.slice(0, 3)) {
        let url;
        try { url = new URL(track.baseUrl); } catch { continue; }
        if (url.protocol !== "https:" || !(url.hostname === "youtube.com" || url.hostname.endsWith(".youtube.com"))) continue;
        if (url.searchParams.get("exp") === "xpe") { emptyTrack = true; continue; }
        for (const format of ["json3", "original"]) {
          const target = new URL(url);
          if (format === "json3") target.searchParams.set("fmt", "json3");
          const timed = await captionFetch(target.href, { credentials: "same-origin" });
          if (!timed.ok) continue;
          const text = await timed.text();
          if (!text.trim()) { emptyTrack = true; continue; }
          let body = [];
          if (format === "json3") {
            try {
              const data = JSON.parse(text);
              body = (data.events || []).filter(event => Array.isArray(event.segs)).map(event => ({
                from: Number(event.tStartMs) / 1000,
                to: (Number(event.tStartMs) + Number(event.dDurationMs || 0)) / 1000,
                content: event.segs.map(seg => seg.utf8 || "").join("").replace(/\s+/g, " ").trim()
              })).filter(item => Number.isFinite(item.from) && item.content);
            } catch { /* Try the original timedtext format. */ }
          } else {
            const xml = new DOMParser().parseFromString(text, "text/xml");
            body = [...xml.querySelectorAll("text, p")].map(item => {
              const from = item.tagName === "p" ? Number(item.getAttribute("t")) / 1000 : Number(item.getAttribute("start"));
              const duration = item.tagName === "p" ? Number(item.getAttribute("d")) / 1000 : Number(item.getAttribute("dur"));
              return { from, to: from + (Number.isFinite(duration) ? duration : 0), content: (item.textContent || "").replace(/\s+/g, " ").trim() };
            }).filter(item => Number.isFinite(item.from) && item.content);
          }
          if (body.length) return { meta, track: { lan: track.languageCode || "", lanDoc: name(track), source: track.kind === "asr" ? "youtube-auto-caption" : "youtube-caption" }, body };
          emptyTrack = true;
        }
      }
    } catch { /* Try the next player client. */ }
  }
  // The transcript panel uses YouTube's own page session and can work when timedtext is empty.
  const panel = ((window.ytInitialData || inlineJson("ytInitialData"))?.engagementPanels || []).find(item =>
    item.engagementPanelSectionListRenderer?.panelIdentifier === "engagement-panel-searchable-transcript"
  )?.engagementPanelSectionListRenderer;
  const params = panel?.content?.continuationItemRenderer?.continuationEndpoint?.getTranscriptEndpoint?.params;
  const context = window.ytcfg?.get?.("INNERTUBE_CONTEXT");
  if (params && context && apiKey) {
    try {
      const response = await captionFetch(`/youtubei/v1/get_transcript?key=${encodeURIComponent(apiKey)}&prettyPrint=false`, {
        method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ context, params })
      });
      if (response.ok) {
        const data = await response.json();
        const panels = (data.actions || []).map(action => action.updateEngagementPanelAction?.content?.transcriptRenderer?.content?.transcriptSearchPanelRenderer).filter(Boolean);
        for (const transcript of panels) {
          const segments = transcript.body?.transcriptSegmentListRenderer?.initialSegments || [];
          const body = segments.map(item => item.transcriptSegmentRenderer).filter(Boolean).map(item => ({
            from: Number(item.startMs) / 1000,
            to: Number(item.endMs || item.startMs) / 1000,
            content: (item.snippet?.runs || []).map(run => run.text || "").join("").replace(/\s+/g, " ").trim()
          })).filter(item => Number.isFinite(item.from) && item.content);
          if (!body.length) continue;
          const options = transcript.footer?.transcriptFooterRenderer?.languageMenu?.sortFilterSubMenuRenderer?.subMenuItems || [];
          const selectedName = options.find(item => item.selected)?.title || "";
          const selectedTrack = tracks.find(track => name(track).toLowerCase() === selectedName.toLowerCase())
            || tracks.find(track => selectedName && (name(track).includes(selectedName) || selectedName.includes(name(track))));
          const selectedFamily = selectedTrack ? family(selectedTrack) : /English|英语|英文/i.test(selectedName) ? "en" : /中文|汉语|Chinese/i.test(selectedName) ? "zh" : "";
          if (language !== "auto" && selectedFamily !== language) continue;
          const track = selectedTrack || candidates.find(item => family(item) === selectedFamily) || candidates[0];
          return { meta, track: { lan: track.languageCode || selectedFamily, lanDoc: selectedName || name(track), source: "youtube-transcript-panel" }, body };
        }
      }
    } catch { /* Report missing only after both page subtitle routes have been tried. */ }
  }
  const opened = await readRenderedTranscript(true);
  if (opened) return opened;
  if (Date.now() >= deadline) throw new Error("YouTube 字幕读取超时；请在视频页确认字幕已显示后重试。");
  if (!candidates.length && language !== "auto") throw new Error(`没有可用的${language === "zh" ? "中文" : "英文"}字幕，请切换为自动选择。`);
  if (emptyTrack || !tracks.length) return { meta, missing: true, body: [] };
  throw new Error("YouTube 字幕轨请求失败；请在视频页确认字幕能显示后重试。");
}

async function youtubeTab(videoId, playlistId) {
  const tabs = await chrome.tabs.query({ url: ["https://www.youtube.com/watch*", "https://m.youtube.com/watch*"] });
  const existing = tabs.filter(tab => {
    try { const url = new URL(tab.url); return url.searchParams.get("v") === videoId && (!playlistId || url.searchParams.get("list") === playlistId); } catch { return false; }
  }).sort((a, b) => Number(b.status === "complete") - Number(a.status === "complete") || Number(b.active) - Number(a.active))[0];
  if (existing) {
    if (existing.status === "complete") return { tab: existing, temporary: false };
    for (let attempt = 0; attempt < 10; attempt++) {
      const current = await chrome.tabs.get(existing.id).catch(() => null);
      if (!current) break;
      if (current.status === "complete") return { tab: current, temporary: false };
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    return { tab: existing, temporary: false };
  }
  const tab = await chrome.tabs.create({ url: `https://www.youtube.com/watch?v=${videoId}${playlistId ? `&list=${playlistId}` : ""}`, active: false });
  for (let attempt = 0; attempt < 40; attempt++) {
    const current = await chrome.tabs.get(tab.id).catch(() => null);
    if (!current) break;
    if (current.status === "complete") return { tab: current, temporary: true };
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  await chrome.tabs.remove(tab.id).catch(() => {});
  throw new Error("YouTube 视频页加载超时，请在浏览器中打开视频后重试。");
}

const youtubeSubtitleCache = new Map();
async function youtubeRead(videoId, preference = "auto", includeBody = false, includeAudio = false, playlistId = "") {
  if (!/^[\w-]{11}$/.test(videoId || "")) throw new Error("请输入有效的 YouTube 视频链接。");
  if (playlistId && !/^[\w-]{8,60}$/.test(playlistId)) throw new Error("YouTube 播放列表链接无效。");
  const cacheKey = `${videoId}:${preference}`;
  const cached = includeBody && !includeAudio && youtubeSubtitleCache.get(cacheKey);
  if (cached && Date.now() - cached.time < 5 * 60 * 1000) return cached.result;
  const { tab, temporary } = await youtubeTab(videoId, playlistId);
  try {
    const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: youtubePageRead, args: [videoId, preference, includeBody, includeAudio, playlistId] });
    if (!results?.[0]?.result) throw new Error("无法读取 YouTube 页面，请确认视频可以播放。");
    const result = results[0].result;
    if (includeBody && result.body?.length) youtubeSubtitleCache.set(cacheKey, { time: Date.now(), result });
    return result;
  } finally {
    if (temporary) await chrome.tabs.remove(tab.id).catch(() => {});
  }
}
